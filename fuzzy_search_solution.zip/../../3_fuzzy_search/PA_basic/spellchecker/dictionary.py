#!/usr/bin/python3.4
# -*- coding: utf-8 -*-

import re
import logging
from collections import Counter

logging.basicConfig(
    format='%(levelname)s %(asctime)s : %(message)s',
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.DEBUG)
logger = logging.getLogger('dictionary')


class Dictionary:
    """
    Класс словаря. Он используется для построения словаря из корпуса запросов,
    хранения слов и частоты их появления. Этот словарь затем будет использоваться
    спеллчекером.
    """
    def __init__(self, file_name=""):
        if not file_name:
            self.words = dict()
        else:
            self.load(file_name)

    def load(self, file_name):
        """Загрузка словаря из файла.

        Словарь хранится в файле в простом несжатом формате:
        ...
        слово \t его частоста
        ...

        На  кажой строке хранится одно слово и частоста встречаемости в корпусе, разделенные
        символом табуляции.

        Параметры:
        - file_name: Имя файла, из которого будет загружен словарь.

        Возвращаемое значение:
        - Данный метод ничего не возвращает.
        """
        self.words = dict()
        with open(file_name, 'rt') as fd:
            for line in fd:
                (word, count) = line.strip('\n').split('\t')
                self.words[word] = int(count)

    def save(self, file_name):
        """Сохранение словаря в файл.

        Параметры:
        - file_name: Имя файла, в который будет сохранен словарь.

        Возвращаемое значение:
        - Данный метод ничего не возвращает.
        """
        with open(file_name, 'wt') as fd:
            for word, count in self.words.items():
                fd.write("{}\t{}\n".format(word, count))

    @staticmethod
    def get_words(line):
        """Получить список слов из строки запроса.

        Данная функция разделяет строку по пробелам.
        Все символы пунктуации и другие символы, не являющиеся буквами или дефисом
        должны быть удалены. Отдельные дефисы так же должны быть удалены.
        Все слова приводятся к нижнему регистру.
        Все слова с числами удаляются.

        Пример:
        по-отечески похлопал - ['по-отечески', 'похлопал']

        Вход:
        - line: строка запроса

        Возврат:
        - Список слов запроса, удовлетворяющих критериям.
        """

        def valid_word(word):
            for c in word:
                if not (c.isalpha() or (c == '-')):
                    return False

            if not word or word == '-':
                return False

            return True

        line = re.sub(r'([^\s\w-]|_)+', ' ', line)
        return [x.lower() for x in line.split(' ') if valid_word(x)]

    def build(self, file_name, threshold=0):
        """Построить словарь из файла с запросами.

        Данная функция строит словарь из корпуса запросов, которые сохранены в файле
        file_name. Если threshold не равен 0, то в слове должны хранится только слова, которые
        встретились в корпусе минимум threshold раз. Это позволяет нам фильтровать слова, написанные
        с ошибками.

        Вход:
        - file_name: имя файла с запросами
        - threshold: опциональный параметр. Если не равен 0, то нужно оставить только те слова,
            которые встречались минимум threshold раз.

        Возврат:
        - Данная функция ничего не возвращает. Словарь должен быть сохранен как self.words.
        """
        cnt = Counter()
        with open(file_name, 'rt') as fd:
            for line in fd:
                line_words = self.get_words(line.strip())
                cnt.update(line_words)
        if threshold == 0:
            self.words = dict(cnt)
        else:
            self.words = {k: v for k, v in cnt.most_common() if v >= threshold}

    def get(self, word):
        """Возвратить частоту слова

        Данная функция возвращает частоту, с которой слово встречалось в корпусе. Если слово не
        встречалось, то необходимо возвратить 0.

        Вход:
        - word: слово

        Возврат:
        - Частота слова в словаре или 0, если слово не встречалось.
        """
        if word in self.words:
            return self.words[word]
        else:
            return 0

    def size(self):
        """Размер словаря.

        Возврат:
        - Размер словаря.
        """
        return len(self.words)

    @staticmethod
    def soundex(word):
        """Возвратить soundex-код слова.

        Данная функция кодирует переданное слово в код soundex. Функция должна работать как для русских,
        так и для английских слов.

        Вход:
        - word: слово

        Возврат:
        - Код soundex для переданного слова.
        """
        if len(word) == 0:
            return ''

        chars = list()
        chars.append(word[0].upper())

        chars_to_delete = ['w', 'h', 'ь', 'ъ']
        vowels = ['a', 'e', 'i', 'o', 'u', 'y', 'й', 'у', 'е', 'ы', 'а', 'о', 'э', 'я', 'и', 'ю']

        consonants = {
            '1': ['b', 'f', 'p', 'v', 'б', 'п', 'ф', 'в'],
            '2': ['c', 'g', 'j', 'k', 'q', 's', 'x', 'z', 'с', 'ц', 'з', 'к', 'г', 'х'],
            '3': ['d', 't', 'д', 'т'],
            '4': ['l', 'л'],
            '5': ['m', 'n', 'м', 'н'],
            '6': ['r', 'р']
        }

        for char in word[1:]:
            if char in chars_to_delete:
                continue

            for k, v in consonants.items():
                if char in v:
                    if chars[-1] != k:
                        chars.append(k)
                    break
            else:
                chars.append(char)

        chars = chars[0:1] + [x for x in chars[1:] if x not in vowels]

        if len(chars) > 4:
            chars = chars[0:4]
        elif len(chars) < 4:
            chars = chars + ['0'] * (4 - len(chars))

        return "".join(chars)
