#!/usr/bin/python3.4
# -*- coding: utf-8 -*-

import logging
import numpy as np
from .dictionary import Dictionary
from collections import defaultdict

logging.basicConfig(
    format='%(levelname)s %(asctime)s : %(message)s',
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.DEBUG)
logger = logging.getLogger('spellchecker')


class Spellchecker:
    """ Класс спеллчекера.
    В нем реализованы функции поиска кандидатов исправлений для слов запроса.
    """
    def __init__(self, arg):
        if isinstance(arg, str):
            self.dictionary = Dictionary(arg)
        elif isinstance(arg, Dictionary):
            self.dictionary = arg
        else:
            self.dictionary = Dictionary()

        self.soundex_index = self.build_soundex_index()

    def build_soundex_index(self):
        """Строит индекс между кодами soundex и словами словаря.

        Для каждого слова из словаря строится код soundex и затем слово добавляется в список,
        соответсвующий этому коду.

        код soundex -> [слово1, слово2, ...]

        Возвращаемое значение:
        - Данный метод ничего не возвращает.
        """
        index = defaultdict(list)
        for word, _ in self.dictionary.words.items():
            index[Dictionary.soundex(word)].append(word)

        return dict(index)

    @staticmethod
    def levenshtein_distance(word1, word2):
        """Расстояние Левенштейна

        Рассчитывает расстояние Левенштейна между словами с операциями вставки, удаления и замены символов.
        Вес каждой операции равен 1.

        Параметры:
        - word1: первое слово
        - word2: второе слово

        Возвращаемое значение:
        - Расстояние между словами word1 и word2.
        """
        size_x = len(word1) + 1
        size_y = len(word2) + 1
        matrix = np.zeros((size_x, size_y))
        for x in range(size_x):
            matrix[x, 0] = x
        for y in range(size_y):
            matrix[0, y] = y

        for x in range(1, size_x):
            for y in range(1, size_y):
                if word1[x - 1] == word2[y - 1]:
                    matrix[x, y] = min(
                        matrix[x - 1, y] + 1,
                        matrix[x - 1, y - 1],
                        matrix[x, y - 1] + 1
                    )
                else:
                    matrix[x, y] = min(
                        matrix[x - 1, y] + 1,
                        matrix[x - 1, y - 1] + 1,
                        matrix[x, y - 1] + 1
                    )
        return matrix[size_x - 1, size_y - 1]

    def is_correct(self, word):
        """Слово есть в словаре

        Параметры:
        - word: слово для проверки

        Возвращаемое значение:
        - True если слово есть в словаре, иначе False
        """
        return self.dictionary.get(word) != 0

    def get_candidates(self, word, max_distance=3):
        """Поиск списка кандидатов для исправления слова

        Возвращает список кандидатов, отсортированных в порядке убывания частоты встречаемости слова в корпусе.
        Таким образом, мы будем для исправления отдавать наиболее часто встречаемы словам в случае равных
        расстояний редактирования.

        В данном методе поиск кандидатов осуществляется перебором всех возможножных вариантов из словаря.

        Параметры:
        - word: слово для исправления
        - max_distance: опциональный параметр, задает допустимое максимальное число исправлений для кандидатов.

        Возвращаемое значение:
        - Список слов кандидатов с минимальным расстоянием редактирования, отсортированных в порядке убывания
        частоты в корпусе.
        """
        min_distance = min(len(word), max_distance)
        candidates = []

        for candidate, count in self.dictionary.words.items():
            distance = Spellchecker.levenshtein_distance(word, candidate)
            if distance < min_distance:
                candidates = [(candidate, count)]
                min_distance = distance
            elif distance == min_distance:
                candidates.append((candidate, count))
        candidates = sorted(candidates, key=lambda x: x[1], reverse=True)
        return [x[0] for x in candidates]

    def get_candidates_fast(self, word, max_distance=3):
        """Быстрый поиск списка кандидатов для исправления слова

        Предыдущий метод работает очень долго - нужно посчитать расстояние между словом и всеми словами из словаря.
        Для того, чтобы сократить список слов для перебора мы будем считать расстояние только между словами,
        имеющими такой же код soundex как и у проверяемого слова.

        Параметры:
        - word: слово для исправления
        - max_distance: опциональный параметр, задает допустимое максимальное число исправлений для кандидатов.

        Возвращаемое значение:
        - Список слов кандидатов с минимальным расстоянием редактирования, отсортированных в порядке убывания
        частоты в корпусе.
        """
        min_distance = min(len(word), max_distance)
        candidates = []

        soundex_code = Dictionary.soundex(word)
        if soundex_code not in self.soundex_index:
            return []

        for candidate in self.soundex_index[soundex_code]:
            distance = Spellchecker.levenshtein_distance(word, candidate)
            if distance < min_distance:
                candidates = [(candidate, self.dictionary.get(candidate))]
                min_distance = distance
            elif distance == min_distance:
                candidates.append((candidate, self.dictionary.get(candidate)))
        candidates = sorted(candidates, key=lambda x: x[1], reverse=True)
        return [x[0] for x in candidates]

