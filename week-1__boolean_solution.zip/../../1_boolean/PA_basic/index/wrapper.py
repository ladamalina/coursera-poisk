#!/usr/bin/python3.4
# -*- coding: utf-8 -*-

import logging
from struct import Struct
from index.lemmatizer import TextLemmatizer

logging.basicConfig(
    format='%(levelname)s %(asctime)s : %(message)s',
    datefmt='%m/%d/%Y %I:%M:%S %p',
    level=logging.DEBUG)
logger = logging.getLogger('index_wrapper')


class IndexPathWrapper:
    main_path = None

    def __init__(self, main_path):
        self.main_path = main_path

    def get_words_dict_path(self):
        return self.main_path + "/words.dic"

    def get_docs_dict_path(self):
        return self.main_path + "/docs.dic"

    def get_index_path(self):
        return self.main_path + "/idx.idx"

    def get_raw_docs_path(self):
        return self.main_path + "/raw_docs.json"


class Matrix:
    m = None
    number_struct = Struct("<I")
    number_pair_struct = Struct("<II")
    max_doc_id = 0

    def __init__(self):
        self.m = []

    def activate(self, line_key, column_key):
        new_pair = (line_key, column_key)
        if column_key > self.max_doc_id:
            self.max_doc_id = column_key
        for i in range(len(self.m)):
            pair = self.m[i]
            if pair[0] == line_key and pair[1] == column_key:
                return
            if pair[0] >= line_key and pair[1] > column_key:
                self.m.insert(i, new_pair)
                return
        self.m.append(new_pair)

    def value(self, line_key, column_key):
        return True if (line_key, column_key) in self.m else False

    def extract_line(self, line_key):
        if self.max_doc_id == 0:
            return 0
        res = []
        for pair in self.m:
            if pair[0] == line_key:
                res.append(pair[1])
        bin_result = 0
        cur_doc_id = 1
        res.sort()
        for doc_id in res:
            if doc_id > cur_doc_id:
                bin_result = (bin_result << (doc_id - cur_doc_id - 1))
            cur_doc_id = doc_id
            bin_result = ((bin_result << 1) + 1)
        bin_result = (bin_result << (self.max_doc_id - cur_doc_id))
        return bin_result

    def load_matrix(self, path):
        self.max_doc_id = 0
        with open(path, "rb") as bin_file:
            bin_data = bin_file.read(self.number_struct.size)
            size = self.number_struct.unpack(bin_data)[0]
            for i in range(size):
                bin_data = bin_file.read(self.number_pair_struct.size)
                pair = self.number_pair_struct.unpack(bin_data)

                if pair[1] > self.max_doc_id:
                    self.max_doc_id = pair[1]
                self.m.append((pair[0], pair[1]))

        logger.info(msg="Load matrix from '" + path + "'. " + str(len(self.m)) + " element(s) loaded.")

    def save_matrix(self, path):
        with open(path, "wb") as bin_file:
            bin_file.write(self.number_struct.pack(len(self.m)))

            for pair in self.m:
                bin_file.write(self.number_pair_struct.pack(pair[0], pair[1]))

        logger.info(msg="Save matrix to '" + path + "'. " + str(len(self.m)) + " element(s) saved.")


class Dictionary:
    d = None
    rev_d = None
    build_rev = False
    dictionary_size = 0
    was_reverted = False
    number_struct = Struct("<I")

    def __init__(self, build_rev=False):
        self.build_rev = build_rev
        self.clean_start()

    def clean_start(self):
        self.d = {}
        if self.build_rev:
            self.rev_d = []
        self.dictionary_size = 0

    def load_dict(self, path, need_revert=False):
        self.clean_start()
        self.was_reverted = need_revert
        with open(path, "rb") as bin_file:
            bin_data = bin_file.read(self.number_struct.size)
            size = self.number_struct.unpack(bin_data)[0]

            for i in range(size):
                bin_data = bin_file.read(self.number_struct.size)
                string_size = self.number_struct.unpack(bin_data)[0]

                record_struct = Struct("%ds" % string_size)
                bin_data = bin_file.read(record_struct.size)
                record = (record_struct.unpack(bin_data)[0]).decode('UTF-8')

                bin_data = bin_file.read(self.number_struct.size)
                key = self.number_struct.unpack(bin_data)[0]
                if need_revert:
                    self.add_elem(key, record)
                else:
                    self.add_elem(record, key)
        logger.info(msg="Load dictionary from '" + path + "'. " + str(self.dictionary_size) + " element(s) loaded.")

    def save_dict(self, path):
        with open(path, "wb") as bin_file:
            bin_file.write(self.number_struct.pack(self.dictionary_size))

            for k in self.d.keys():
                key = k.encode('utf-8')
                key_len = len(key)
                bin_file.write(self.number_struct.pack(key_len))
                record_struct = Struct("%ds" % key_len)
                bin_file.write(record_struct.pack(key))
                bin_file.write(self.number_struct.pack(self.d[k]))
        logger.info(msg="Save dictionary to '" + path + "'. " + str(self.dictionary_size) + " element(s) saved.")

    def add_elem(self, elem, key):
        if elem in self.d:
            return self.d[elem]

        self.dictionary_size = self.dictionary_size + 1

        if self.build_rev:
            while key in self.rev_d:
                key = key + 1

            self.d[elem] = key
            for i in range(len(self.rev_d)):
                if self.rev_d[i] > key:
                    self.rev_d.insert(i, key)
                    return key
            self.rev_d.append(key)
            return key
        else:
            self.d[elem] = key
            return key

    def make_reverted(self):
        self.clean_revert()
        new_dictionary = {}
        for obj, obj_id in self.d.items():
            new_dictionary[obj_id] = obj
        self.d = new_dictionary
        self.was_reverted = True

    def clean_revert(self):
        self.build_rev = False
        self.rev_d = None

    def get_key(self, elem):
        if elem in self.d:
            return self.d[elem]
        else:
            return None


class Wrapper:
    words_dict = None
    docs_dict = None
    matrix = None
    lemmatizer = None

    def __init__(self, index_path):
        ipw = IndexPathWrapper(index_path)

        self.words_dict = Dictionary()
        self.words_dict.load_dict(ipw.get_words_dict_path())

        self.docs_dict = Dictionary(True)
        self.docs_dict.load_dict(ipw.get_docs_dict_path(), True)

        self.matrix = Matrix()
        self.matrix.load_matrix(ipw.get_index_path())

        self.lemmatizer = TextLemmatizer()
